# Hero Subtitle Fix — CC Handoff
# Two files, surgical edits only.

=================================================================
## FILE 1 — project-detail.component.ts
=================================================================

In client-angular/src/app/features/projects/pages/project-detail/project-detail.component.ts

In the pushContext() method, make EXACTLY these two changes:

CHANGE 1 — Remove heroSub (no status shown):
  Find:   heroSub:    '',
  Change: heroSub:    '',
  (leave as empty string — no change needed here, it's already '')

CHANGE 2 — Uppercase the tab labels:
  Find:
    const tabs = [
      { label: 'Brief',     path: `/projects/${this.pid}/brief` },
      { label: 'Build',     path: `/projects/${this.pid}/build` },
      { label: 'Estimate',  path: `/projects/${this.pid}/estimate` },
    ];

  Replace with:
    const tabs = [
      { label: 'Brief',     path: `/projects/${this.pid}/brief` },
      { label: 'Build',     path: `/projects/${this.pid}/build` },
      { label: 'Estimate',  path: `/projects/${this.pid}/estimate` },
    ];

  NOTE: The tab labels Brief/Build/Estimate stay mixed case — the CSS 
  will handle uppercase display. The active tab gets theme-accent colour,
  inactive tabs get color-text-muted (gray). This is already handled by
  .bp-hero-tab and .bp-hero-tab.active in styles.css.

  The REAL fix needed is that heroSub is showing "ACTIVE" — this means
  CC's previous commit did NOT actually change the file. 
  
  Look at the ACTUAL current content of pushContext() and find where 
  heroSub is being set to the project status. It may be:
    heroSub: sub || 'Project',
  or
    heroSub: (sub || 'Project').toUpperCase(),
  
  Change it to:
    heroSub: '',

=================================================================
## FILE 2 — styles.css
=================================================================

In client-angular/src/styles.css

Find .bp-hero-page-label and replace the color line:
  color: var(--color-text-muted);
With:
  color: var(--theme-text) !important;

The full rule should be:
  .bp-hero-page-label {
    font-size: 11px;
    font-weight: 600;
    color: var(--theme-text) !important;
    text-transform: uppercase;
    letter-spacing: 0.1em;
    margin-bottom: 20px;
  }

Also find .bp-hero-tab.active and ensure it uses theme-accent:
  .bp-hero-tab.active { 
    color: var(--theme-accent) !important; 
    font-weight: 600 !important; 
  }

And .bp-hero-tab (inactive):
  .bp-hero-tab { 
    color: var(--color-text-muted) !important; 
  }

=================================================================

IMPORTANT: Before committing, verify the actual current content of 
pushContext() by reading the file first. CC's last commit claimed to 
make changes that clearly did not apply. Read the file, confirm the 
heroSub value, then fix it.

ng build
git add .
git commit -m "fix: project hero — remove status subtitle, hero-page-label theme-text colour"
git push origin dev
