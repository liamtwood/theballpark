# Messages Update — CC Handoff

## File to replace
client-angular/src/app/features/projects/pages/project-detail/tabs/messages/messages.component.ts
→ replace entirely with messages.component.ts from this zip

## What's built

### Status filter bar (top)
Horizontal pills: All | Action Needed | Follow Up | Quoted | Booked
- Each pill shows count of messages with that status
- Active pill fills with the status colour (red/amber/blue/green)
- Works independently of folder selection

### Category folders (left sidebar)
- All Messages + one folder per project category
- Folder badge shows count of "Action Needed" inbound messages
- On mobile: collapses to horizontal scrollable tab row

### Message thread (right)
- Bubbles: inbound left, outbound right (parchment background)
- In "All" folder: category tag shown on each bubble
- In category folder: no category tag
- Thread header shows folder name + active status tag if filtered
- Date separators between days
- Auto-scrolls to bottom on load

### Per-message status tags (on inbound messages only)
- Action Needed | Follow Up | Quoted | Booked
- Tap to apply, tap again to clear
- Active tag fills with colour
- Persists via MessageService.update()

### Compose
- Placeholder changes: "Message re: [Category]..." when in a folder
- Sends with category_id if in a category folder

---

## DB changes needed

Run in migrate.js (and migrate-schemas.js for preview/master):

ALTER TABLE messages ADD COLUMN IF NOT EXISTS category_id UUID REFERENCES project_categories(id);
ALTER TABLE messages ADD COLUMN IF NOT EXISTS msg_status VARCHAR(50);

Also add update() method to MessageService if not present:
  update(id: string, data: any) { return this.api.patch<Message>(`/messages/${id}`, data); }

And add PATCH route to server/src/routes/messages.js:
  router.patch('/:id', async (req, res, next) => {
    try {
      const msg = await MessageService.update(req.params.id, req.body);
      if (!msg) return res.status(404).json({ error: 'Not found' });
      res.json(msg);
    } catch (err) { next(err); }
  });

And add update() to server/src/services/message.service.js:
  async function update(id, data) {
    const { msg_status, read } = data;
    const result = await pool.query(
      `UPDATE messages SET
        msg_status = COALESCE($1, msg_status),
        read = COALESCE($2, read),
        updated_at = NOW()
       WHERE id = $3 RETURNING *`,
      [msg_status, read, id]
    );
    return result.rows[0] || null;
  }
  // Add to module.exports

---

ng build
git add .
git commit -m "feat: messages tab — email layout, status filter, category folders, per-message tagging"
git push origin dev
